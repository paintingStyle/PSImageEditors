//
//  PSImageEditorTabBar.h
//  PSImageEditors
//
//  Created by rsf on 2018/11/14.
//  Copyright © 2018年 paintingStyle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSImageEditorTabBar : UIView

- (void)setTabBarShow:(BOOL)show animation:(BOOL)animation;

@end
