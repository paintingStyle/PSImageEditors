//
//  PSImageEditorsViewController.m
//  PSImageEditors
//
//  Created by rsf on 2018/11/14.
//  Copyright © 2018年 paintingStyle. All rights reserved.
//

#import "PSImageEditorsViewController.h"
#import "PSImageEditorTopBar.h"

static const NSInteger kMinimumZoomScale = 1.0;
static const NSInteger kMaximumZoomScale = 2.5f;

@interface PSImageEditorsViewController ()<UIScrollViewDelegate> {
	BOOL _navigationBarHidden;
}

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong, readwrite) UIImageView *imageView;
@property (nonatomic, strong, readwrite) PSImageEditorCanvasView *brushCanvasView;
@property (nonatomic, strong, readwrite) PSImageEditorCanvasView *mosaicCanvasView;

@property (nonatomic, strong) UIImage *originImage;
@property (nonatomic, strong) PSImageEditorTopBar *topBar;

@property (nonatomic, strong) UITapGestureRecognizer *singleGesture;

@end

@implementation PSImageEditorsViewController

- (instancetype)initWithImage:(UIImage *)image {
	if (self = [super init]) {
		_originImage = image;
	}
	return self;
}

#pragma mark - Life Cycle

- (void)viewDidLoad {
	
	[super viewDidLoad];
	[self configUI];
}

- (void)viewWillAppear:(BOOL)animated {
	
	[super viewWillAppear:animated];
	_navigationBarHidden = self.navigationController.navigationBar.hidden;
	[self.navigationController setNavigationBarHidden:YES animated:NO];
	//ShowBusyIndicatorForView(self.view);
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		//  HideBusyIndicatorForView(self.view);
		[self refreshImageView];
	});
}

- (void)viewDidAppear:(BOOL)animated {
	
	[super viewDidAppear:animated];
//	[self.topToolBar setToolBarShow:YES animation:YES];
//	[self.bottomToolBar setToolBarShow:YES animation:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
	
	[super viewWillDisappear:animated];
	[self.navigationController setNavigationBarHidden:_navigationBarHidden animated:NO];
}

- (void)viewDidLayoutSubviews {
	[super viewDidLayoutSubviews];
	
//	if (!self.canvasView.superview) {
//		self.canvasView.frame = self.imageView.superview.frame;
//		self.canvasView.contentMode = UIViewContentModeCenter;
//		self.canvasView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin;
//		[self.imageView.superview addSubview:self.canvasView];
//	}
	
//	if (!self.drawingView) {
//		self.drawingView = [[UIImageView alloc] initWithFrame:self.imageView.superview.frame];
//		self.drawingView.contentMode = UIViewContentModeCenter;
//		self.drawingView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin;
//		[self.imageView.superview addSubview:self.drawingView];
//		self.drawingView.userInteractionEnabled = YES;
//	} else {
//		//self.drawingView.frame = self.imageView.superview.frame;
//	}
//
//
//	self.topBannerView.frame = CGRectMake(0, 0, self.imageView.width, CGRectGetMinY(self.imageView.frame));
//	self.bottomBannerView.frame = CGRectMake(0, CGRectGetMaxY(self.imageView.frame), self.imageView.width, self.drawingView.height - CGRectGetMaxY(self.imageView.frame));
//	self.leftBannerView.frame = CGRectMake(0, 0, CGRectGetMinX(self.imageView.frame), self.drawingView.height);
//	self.rightBannerView.frame= CGRectMake(CGRectGetMaxX(self.imageView.frame), 0, self.drawingView.width - CGRectGetMaxX(self.imageView.frame), self.drawingView.height);
}

- (BOOL)prefersStatusBarHidden {
	return YES;
}

#pragma mark - Method

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)refreshImageView {
	if (self.imageView.image == nil) {
		self.imageView.image = self.originImage;
	}
	
	[self resetImageViewFrame];
	[self resetZoomScaleWithAnimated:NO];
	[self viewDidLayoutSubviews];
}

- (void)resetImageViewFrame {
	CGSize size = (_imageView.image) ? _imageView.image.size : _imageView.frame.size;
	if(size.width > 0 && size.height > 0 ) {
		CGFloat ratio = MIN(_scrollView.frame.size.width / size.width, _scrollView.frame.size.height / size.height);
		CGFloat W = ratio * size.width * _scrollView.zoomScale;
		CGFloat H = ratio * size.height * _scrollView.zoomScale;
	
		_imageView.frame = CGRectMake(MAX(0, (CGRectGetWidth(_scrollView.frame) -W)/2), MAX(0, (CGRectGetHeight(_scrollView.frame)-H)/2), W, H);
		self.mosaicCanvasView.frame = _imageView.frame;
		self.brushCanvasView.frame = _imageView.frame;
	}
}

- (void)resetZoomScaleWithAnimated:(BOOL)animated
{
	CGFloat Rw = _scrollView.frame.size.width / _imageView.frame.size.width;
	CGFloat Rh = _scrollView.frame.size.height / _imageView.frame.size.height;

	CGFloat scale = [[UIScreen mainScreen] scale];
	//CGFloat scale = 1;
	Rw = MAX(Rw, _imageView.image.size.width / (scale * _scrollView.frame.size.width));
	Rh = MAX(Rh, _imageView.image.size.height / (scale * _scrollView.frame.size.height));

	_scrollView.contentSize = _imageView.frame.size;
	_scrollView.minimumZoomScale = 1;
	_scrollView.maximumZoomScale = MAX((MAX(Rw, Rh)), 3);

	[_scrollView setZoomScale:_scrollView.minimumZoomScale animated:animated];
	[self scrollViewDidZoom:_scrollView];
}

#pragma mark - Delegate

#pragma mark - 单击手势点击事件

- (void)singleGestureClicked {
	
	
}

#pragma mark - UIScrollViewDelegate

#pragma mark - 使用捏合手势时，这个方法返回的控件就是需要进行缩放的控件

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {

	return self.imageView.superview;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {

}

#pragma mark - InitAndLayout

- (void)configUI {
	
	[self.view addSubview:self.scrollView];

	
	[self.scrollView addSubview:self.contentView];

	
	self.imageView = [[UIImageView alloc] initWithImage:self.originImage];
	[self.contentView addSubview:self.imageView];

	
	[self.contentView addSubview:self.mosaicCanvasView];

	
	
	
	[self.contentView addSubview:self.brushCanvasView];
	

	[self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.edges.equalTo(self.view);
	}];
	
	[self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.edges.equalTo(self.scrollView);
		make.center.equalTo(self.scrollView);
	}];
	
	[self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.edges.equalTo(self.contentView);
	}];
	[self.mosaicCanvasView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.edges.equalTo(self.contentView);
	}];
	[self.brushCanvasView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.edges.equalTo(self.contentView);
	}];
	
	self.mosaicCanvasView.backgroundColor = [UIColor redColor];
	self.textCanvasView.backgroundColor = [UIColor greenColor];
	self.brushCanvasView.backgroundColor = [UIColor blueColor];
}

- (void)updateViewConstraints {
	
	
	
	[super updateViewConstraints];
}

#pragma mark - Getter/Setter

- (PSImageEditorTopBar *)topBar {
	
	return LAZY_LOAD(_topBar, ({
		
		_topBar = [[PSImageEditorTopBar alloc] init];
		_topBar;
	}));
}

- (PSImageEditorCanvasView *)mosaicCanvasView {
	
	return LAZY_LOAD(_mosaicCanvasView, ({
		
		_mosaicCanvasView = [[PSImageEditorCanvasView alloc] init];
		_mosaicCanvasView;
	}));
}

- (PSImageEditorCanvasView *)brushCanvasView {
	
	return LAZY_LOAD(_brushCanvasView, ({
		
		_brushCanvasView = [[PSImageEditorCanvasView alloc] init];
		_brushCanvasView;
	}));
}

- (UIImageView *)imageView {
	
	return LAZY_LOAD(_imageView, ({
		
		_imageView = [[UIImageView alloc] init];
		_imageView.contentMode = UIViewContentModeCenter;
		_imageView;
	}));
}

- (UIView *)contentView {
	
	return LAZY_LOAD(_contentView, ({
		
		_contentView = [[UIView alloc] init];
		_contentView;
	}));
}

- (UIScrollView *)scrollView {
	
	return LAZY_LOAD(_scrollView, ({
		
		_scrollView = [[UIScrollView alloc] init];
		_scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		_scrollView.delegate = self;
		_scrollView.multipleTouchEnabled = YES;
		_scrollView.showsHorizontalScrollIndicator = NO;
		_scrollView.showsVerticalScrollIndicator = NO;
		_scrollView.delaysContentTouches = NO;
		_scrollView.scrollsToTop = NO;
		_scrollView.clipsToBounds = NO;
		if(@available(iOS 11.0, *)) {
			_scrollView.contentInsetAdjustmentBehavior =
			UIScrollViewContentInsetAdjustmentNever;
		}
		_singleGesture = [[UITapGestureRecognizer alloc] initWithTarget:self
																 action:@selector(singleGestureClicked)];
		[_scrollView addGestureRecognizer:_singleGesture];
		_scrollView;
	}));
}

@end
