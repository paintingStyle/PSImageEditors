//
//  PSNavigationController.h
//  PSImageEditors
//
//  Created by paintingStyle on 2018/8/25.
//  Copyright © 2018年 paintingStyle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSNavigationController : UINavigationController

@end
