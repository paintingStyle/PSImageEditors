//
//  PSImageEditorCanvasView.m
//  PSImageEditors
//
//  Created by rsf on 2018/11/14.
//

#import "PSImageEditorCanvasView.h"

@interface PSImageEditorCanvasView ()

@end

@implementation PSImageEditorCanvasView

- (instancetype)init {
	if (self = [super init]) {
		self.contentMode = UIViewContentModeCenter;
		self.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin;
	}
	return self;
}

@end
