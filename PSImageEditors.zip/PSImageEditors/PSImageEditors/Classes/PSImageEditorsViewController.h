//
//  PSImageEditorsViewController.h
//  PSImageEditors
//
//  Created by rsf on 2018/11/14.
//  Copyright © 2018年 paintingStyle. All rights reserved.
//

@protocol PSImageEditorsDelegate,PSImageEditorsDataSource;
#import <UIKit/UIKit.h>
#import "PSImageEditorCanvasView.h"

typedef NS_ENUM(NSUInteger, PSImageEditorsMode) {
	
	PSImageEditorsModeNone,
	PSImageEditorsModeBrush,
	PSImageEditorsModeText,
	PSImageEditorsModeMosaic,
	PSImageEditorsModeClipping
};

@interface PSImageEditorsViewController : UIViewController

/// 最底层负责显示的图片
@property (nonatomic, strong, readonly) UIImageView *imageView;
/// 画笔画布
@property (nonatomic, strong, readonly) PSImageEditorCanvasView *brushCanvasView;
/// 文字画布
@property (nonatomic, strong, readonly) PSImageEditorCanvasView *textCanvasView;
/// 马赛克画布
@property (nonatomic, strong, readonly) PSImageEditorCanvasView *mosaicCanvasView;

@property (nonatomic, weak) id<PSImageEditorsDelegate> delegate;
@property (nonatomic, weak) id<PSImageEditorsDataSource> dataSource;
@property (nonatomic, assign) PSImageEditorsMode currentMode;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new  NS_UNAVAILABLE;
- (instancetype)initWithImage:(UIImage *)image;

@end

@protocol PSImageEditorsDelegate <NSObject>

@optional
- (void)imageEditorsDidFinishEdittingWithImage:(UIImage *)image;
- (void)imageEditorsDidCancel;

@end

@protocol PSImageEditorsDataSource <NSObject>

@optional
- (UIColor *)imageEditorDefaultColor;
- (NSNumber *)imageEditorDrawPathWidth;

@end
