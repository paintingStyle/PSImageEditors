//
//  PSViewController.m
//  PSImageEditors
//
//  Created by rsf on 2018/8/24.
//  Copyright © 2018年 paintingStyle. All rights reserved.
//

#import "PSViewController.h"
#import <PSImageEditorsViewController.h>
#import <FLAnimatedImage/FLAnimatedImage.h>

@interface PSViewController ()

@property (nonatomic, copy) NSArray *images;
@property (nonatomic, copy) NSArray *urls;

@end

@implementation PSViewController

- (void)viewDidLoad {
	[super viewDidLoad];
}

- (IBAction)imageBrowsingDidClicked {
	
	UIImage *image = [UIImage imageNamed:@"localImage_01@2x.jpg"];
	PSImageEditorsViewController *controller = [[PSImageEditorsViewController alloc] initWithImage:image];
	[self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)imageEditorsDidClicked {
	
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    
    return UIStatusBarStyleLightContent;
}

@end
