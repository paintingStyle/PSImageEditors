//
//  PSImageEditorCanvasView.h
//  PSImageEditors
//
//  Created by rsf on 2018/11/14.
//  图片编辑画布

#import <UIKit/UIKit.h>

@interface PSImageEditorCanvasView : UIImageView

@end

